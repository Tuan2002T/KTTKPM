package se.fit.UserRedis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
